"""
MT5 Bridge Server — Run this on Windows (where MT5 is installed)
================================================================
The AI bot on Mac connects to this server via REST API.
This server relays trade orders to your real Exness MT5 account.

SETUP (Windows only):
  1. pip install flask MetaTrader5
  2. Set environment variables (or edit defaults below):
       MT5_LOGIN    = your Exness login number
       MT5_PASSWORD = your Exness password
       MT5_SERVER   = Exness-MT5Trial14  (or your server name)
       BRIDGE_TOKEN = any secret string (copy to Mac .env)
  3. Run: python mt5_bridge_server.py
  4. On Mac .env add:
       EXECUTION_MODE=live
       MT5_MODE=bridge
       MT5_BRIDGE_URL=http://<windows-ip>:5000
       MT5_BRIDGE_TOKEN=<same token>

Port 5000 must be reachable from Mac (same network or VPS with open port).
"""

import os
from flask import Flask, request, jsonify

app = Flask(__name__)

# ── Config — edit these or set as environment variables ──
MT5_LOGIN    = int(os.getenv("MT5_LOGIN",    "0"))
MT5_PASSWORD = os.getenv("MT5_PASSWORD",     "")
MT5_SERVER   = os.getenv("MT5_SERVER",       "Exness-MT5Trial14")
BRIDGE_TOKEN = os.getenv("MT5_BRIDGE_TOKEN", "nexus_bridge_2026")  # change this!


def _auth(req) -> bool:
    token = req.headers.get("Authorization", "").replace("Bearer ", "").strip()
    return token == BRIDGE_TOKEN


def _init():
    """Connect to MT5 — raises on failure."""
    import MetaTrader5 as mt5
    if not mt5.initialize():
        raise RuntimeError(f"MT5 init failed: {mt5.last_error()}")
    if not mt5.login(MT5_LOGIN, MT5_PASSWORD, MT5_SERVER):
        raise RuntimeError(f"MT5 login failed: {mt5.last_error()}")
    return mt5


# ── Health ────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    try:
        mt5 = _init()
        info = mt5.terminal_info()
        mt5.shutdown()
        return jsonify({"ok": True, "connected": True,
                        "build": info.build if info else 0})
    except Exception as e:
        return jsonify({"ok": False, "connected": False, "error": str(e)})


# ── Account ───────────────────────────────────────────────

@app.route("/account", methods=["GET"])
def get_account():
    if not _auth(request):
        return jsonify({"error": "Unauthorized"}), 401
    try:
        mt5 = _init()
        info = mt5.account_info()
        mt5.shutdown()
        if not info:
            return jsonify({"error": "No account info"})
        return jsonify({
            "balance":      round(info.balance, 2),
            "equity":       round(info.equity, 2),
            "margin":       round(info.margin, 2),
            "free_margin":  round(info.margin_free, 2),
            "profit":       round(info.profit, 2),
            "currency":     info.currency,
            "name":         info.name,
            "server":       info.server,
            "login":        info.login,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Place Order ──────────────────────────────────────────

@app.route("/place_order", methods=["POST"])
def place_order():
    if not _auth(request):
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    data      = request.json or {}
    symbol    = data.get("symbol",    "XAUUSDm")
    direction = data.get("direction", "BUY")
    lot       = float(data.get("lot", 0.01))
    sl        = float(data.get("sl",  0))
    tp        = float(data.get("tp",  0))
    comment   = data.get("comment",   "AiBot")

    try:
        mt5    = _init()
        action = mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL
        tick   = mt5.symbol_info_tick(symbol)
        if not tick:
            mt5.shutdown()
            return jsonify({"success": False, "error": f"Symbol {symbol} not found"})

        price = tick.ask if direction == "BUY" else tick.bid

        req_obj = {
            "action":       mt5.TRADE_ACTION_DEAL,
            "symbol":       symbol,
            "volume":       lot,
            "type":         action,
            "price":        price,
            "sl":           sl,
            "tp":           tp,
            "comment":      comment,
            "type_time":    mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(req_obj)
        mt5.shutdown()

        if result and result.retcode == mt5.TRADE_RETCODE_DONE:
            return jsonify({
                "success": True,
                "ticket":  result.order,
                "price":   result.price,
                "volume":  result.volume,
            })

        retcode = result.retcode if result else -1
        comment = result.comment if result else "no result"
        return jsonify({"success": False,
                        "error": f"retcode={retcode} {comment}"})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ── Close Order ──────────────────────────────────────────

@app.route("/close_order", methods=["POST"])
def close_order():
    if not _auth(request):
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    ticket = int((request.json or {}).get("ticket", 0))

    try:
        mt5       = _init()
        positions = mt5.positions_get(ticket=ticket)

        if not positions:
            mt5.shutdown()
            return jsonify({"success": False, "error": "Position not found"})

        pos    = positions[0]
        action = (mt5.ORDER_TYPE_SELL
                  if pos.type == mt5.ORDER_TYPE_BUY
                  else mt5.ORDER_TYPE_BUY)
        tick   = mt5.symbol_info_tick(pos.symbol)
        price  = tick.bid if action == mt5.ORDER_TYPE_SELL else tick.ask

        result = mt5.order_send({
            "action":       mt5.TRADE_ACTION_DEAL,
            "symbol":       pos.symbol,
            "volume":       pos.volume,
            "type":         action,
            "position":     ticket,
            "price":        price,
            "comment":      "AiBot_close",
            "type_time":    mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        })
        mt5.shutdown()

        ok = result and result.retcode == mt5.TRADE_RETCODE_DONE
        return jsonify({"success": ok,
                        "retcode": result.retcode if result else -1})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ── Get Positions ─────────────────────────────────────────

@app.route("/positions", methods=["GET"])
def get_positions():
    if not _auth(request):
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    try:
        mt5       = _init()
        positions = mt5.positions_get() or []
        mt5.shutdown()

        result = []
        for p in positions:
            result.append({
                "ticket":    p.ticket,
                "symbol":    p.symbol,
                "direction": "BUY" if p.type == 0 else "SELL",
                "volume":    p.volume,
                "entry":     p.price_open,
                "sl":        p.sl,
                "tp":        p.tp,
                "pnl":       round(p.profit, 2),
                "current":   p.price_current,
                "comment":   p.comment,
            })
        return jsonify({"positions": result})

    except Exception as e:
        return jsonify({"positions": [], "error": str(e)}), 500


# ── Main ──────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"""
╔══════════════════════════════════════════╗
║       MT5 Bridge Server — NEXUS GOLD     ║
╠══════════════════════════════════════════╣
║  Login  : {str(MT5_LOGIN):<30} ║
║  Server : {MT5_SERVER:<30} ║
║  Port   : 5000                           ║
║  Token  : {BRIDGE_TOKEN[:8]}...                      ║
╚══════════════════════════════════════════╝

Endpoints:
  GET  /health          — check MT5 connection
  GET  /account         — get balance/equity
  POST /place_order     — open a trade
  POST /close_order     — close a trade
  GET  /positions       — list open trades

Press Ctrl+C to stop.
""")
    app.run(host="0.0.0.0", port=5000, debug=False)
