"""
Execution Engine
────────────────
Unified interface for trade execution.
  PAPER mode  → logs virtual trades, tracks P&L internally
  BRIDGE mode → calls MT5 REST bridge on Windows VPS
  NATIVE mode → calls MT5 Python lib directly (VPS only)
"""

import uuid
import json
from datetime import datetime
from typing import Optional
from dataclasses import dataclass, asdict, field
from loguru import logger
import httpx

from config.settings import settings
from bot.risk_engine import TradeParams, record_trade_result


@dataclass
class OrderResult:
    success: bool
    ticket: str
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    lot_size: float
    mode: str           # paper | bridge | native
    message: str = ""
    opened_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class PaperTrade:
    ticket: str
    symbol: str
    direction: str
    entry: float
    stop_loss: float
    take_profit_1: float
    take_profit_2: float
    lot_size: float
    open_time: str
    current_price: float = 0.0
    pnl: float = 0.0
    status: str = "OPEN"   # OPEN | CLOSED | SL_HIT | TP_HIT
    close_price: float = 0.0
    close_time: str = ""


# ── Paper Trade Store ──────────────────────────────────
_paper_trades: dict[str, PaperTrade] = {}


def get_paper_trades() -> list[PaperTrade]:
    return list(_paper_trades.values())


def get_open_paper_trades() -> list[PaperTrade]:
    return [t for t in _paper_trades.values() if t.status == "OPEN"]


def update_paper_pnl(current_price: float):
    """Update unrealised P&L for open paper trades."""
    for trade in get_open_paper_trades():
        if trade.direction == "BUY":
            trade.pnl = round((current_price - trade.entry) * trade.lot_size * 100, 2)
        else:
            trade.pnl = round((trade.entry - current_price) * trade.lot_size * 100, 2)
        trade.current_price = current_price

        # Auto-close on SL/TP hit
        if trade.direction == "BUY":
            if current_price <= trade.stop_loss:
                _close_paper_trade(trade, current_price, "SL_HIT")
            elif current_price >= trade.take_profit_1:
                _close_paper_trade(trade, current_price, "TP_HIT")
        else:
            if current_price >= trade.stop_loss:
                _close_paper_trade(trade, current_price, "SL_HIT")
            elif current_price <= trade.take_profit_1:
                _close_paper_trade(trade, current_price, "TP_HIT")


def _close_paper_trade(trade, close_price: float, reason: str):
    # Guard: never double-close a trade
    if getattr(trade, "status", "OPEN") != "OPEN":
        logger.debug(f"Skip close {getattr(trade,'ticket','?')} — already {trade.status}")
        return
    trade.status = reason
    trade.close_price = close_price
    trade.close_time = datetime.now().isoformat()
    if trade.direction == "BUY":
        trade.pnl = round((close_price - trade.entry) * trade.lot_size * 100, 2)
    else:
        trade.pnl = round((trade.entry - close_price) * trade.lot_size * 100, 2)
    record_trade_result(trade.pnl)
    logger.info(f"Paper trade {reason}: ticket={trade.ticket} pnl={trade.pnl}")


# ── Paper Execution ────────────────────────────────────

def _execute_paper(params: TradeParams) -> OrderResult:
    ticket = f"PAPER-{str(uuid.uuid4())[:8].upper()}"
    trade = PaperTrade(
        ticket=ticket,
        symbol=params.symbol,
        direction=params.direction,
        entry=params.entry,
        stop_loss=params.stop_loss,
        take_profit_1=params.take_profit_1,
        take_profit_2=params.take_profit_2,
        lot_size=params.lot_size,
        open_time=datetime.now().isoformat(),
        current_price=params.entry,
    )
    _paper_trades[ticket] = trade
    logger.info(
        f"[PAPER] {params.direction} {params.symbol} "
        f"entry={params.entry} sl={params.stop_loss} "
        f"tp={params.take_profit_1} lot={params.lot_size}"
    )
    return OrderResult(
        success=True,
        ticket=ticket,
        symbol=params.symbol,
        direction=params.direction,
        entry=params.entry,
        stop_loss=params.stop_loss,
        take_profit=params.take_profit_1,
        lot_size=params.lot_size,
        mode="paper",
        message="Paper trade opened",
    )


# ── Bridge Execution (Mac → VPS MT5) ──────────────────

async def _execute_bridge(params: TradeParams) -> OrderResult:
    """Send order to MT5 REST bridge running on Windows VPS."""
    payload = {
        "symbol": params.symbol,
        "direction": params.direction,
        "lot": params.lot_size,
        "sl": params.stop_loss,
        "tp": params.take_profit_1,
        "comment": f"AiBot_{params.session}",
    }
    headers = {"Authorization": f"Bearer {settings.mt5_bridge_token}"}
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"{settings.mt5_bridge_url}/place_order",
                json=payload,
                headers=headers,
            )
            data = resp.json()
            if data.get("success"):
                logger.info(f"[BRIDGE] Order placed: ticket={data.get('ticket')}")
                return OrderResult(
                    success=True,
                    ticket=str(data.get("ticket", "")),
                    symbol=params.symbol,
                    direction=params.direction,
                    entry=data.get("price", params.entry),
                    stop_loss=params.stop_loss,
                    take_profit=params.take_profit_1,
                    lot_size=params.lot_size,
                    mode="bridge",
                    message="Live order via MT5 bridge",
                )
            else:
                err = data.get("error", "Unknown bridge error")
                logger.error(f"[BRIDGE] Order failed: {err}")
                return OrderResult(
                    success=False, ticket="", symbol=params.symbol,
                    direction=params.direction, entry=params.entry,
                    stop_loss=params.stop_loss, take_profit=params.take_profit_1,
                    lot_size=params.lot_size, mode="bridge", message=err,
                )
    except Exception as e:
        logger.error(f"[BRIDGE] Connection error: {e}")
        return OrderResult(
            success=False, ticket="", symbol=params.symbol,
            direction=params.direction, entry=params.entry,
            stop_loss=params.stop_loss, take_profit=params.take_profit_1,
            lot_size=params.lot_size, mode="bridge",
            message=f"Bridge unreachable: {e}",
        )


async def close_bridge_trade(ticket: str) -> bool:
    """Close a live trade via bridge."""
    headers = {"Authorization": f"Bearer {settings.mt5_bridge_token}"}
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"{settings.mt5_bridge_url}/close_order",
                json={"ticket": ticket},
                headers=headers,
            )
            return resp.json().get("success", False)
    except Exception as e:
        logger.error(f"Bridge close failed: {e}")
        return False


async def get_bridge_positions() -> list[dict]:
    """Get open positions via bridge."""
    headers = {"Authorization": f"Bearer {settings.mt5_bridge_token}"}
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{settings.mt5_bridge_url}/positions",
                headers=headers,
            )
            return resp.json().get("positions", [])
    except Exception as e:
        logger.error(f"Bridge positions failed: {e}")
        return []


# ── Unified Execute ────────────────────────────────────

async def execute_trade(params: TradeParams) -> OrderResult:
    """
    Main entry point — routes to paper/bridge/native based on config.
    """
    if settings.is_paper:
        return _execute_paper(params)
    elif settings.use_mt5_bridge:
        return await _execute_bridge(params)
    else:
        # Native MT5 — only available on Windows VPS
        try:
            import MetaTrader5 as mt5
            return await _execute_native_mt5(params, mt5)
        except ImportError:
            logger.error("MetaTrader5 library not available on Mac. Use paper or bridge mode.")
            return OrderResult(
                success=False, ticket="", symbol=params.symbol,
                direction=params.direction, entry=params.entry,
                stop_loss=params.stop_loss, take_profit=params.take_profit_1,
                lot_size=params.lot_size, mode="native",
                message="MT5 not available — switch to bridge mode on Mac",
            )


async def _execute_native_mt5(params: TradeParams, mt5) -> OrderResult:
    """Direct MT5 execution — Windows VPS only."""
    action = mt5.ORDER_TYPE_BUY if params.direction == "BUY" else mt5.ORDER_TYPE_SELL
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": params.symbol,
        "volume": params.lot_size,
        "type": action,
        "sl": params.stop_loss,
        "tp": params.take_profit_1,
        "comment": f"AiBot_{params.session}",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    result = mt5.order_send(request)
    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        return OrderResult(
            success=True, ticket=str(result.order),
            symbol=params.symbol, direction=params.direction,
            entry=result.price, stop_loss=params.stop_loss,
            take_profit=params.take_profit_1, lot_size=params.lot_size,
            mode="native", message="Live MT5 order placed",
        )
    err = f"MT5 error: {result.retcode if result else 'no result'}"
    return OrderResult(
        success=False, ticket="", symbol=params.symbol,
        direction=params.direction, entry=params.entry,
        stop_loss=params.stop_loss, take_profit=params.take_profit_1,
        lot_size=params.lot_size, mode="native", message=err,
    )
